Model by Reallusion iClone from Google 3d Warehouse:

http://sketchup.google.com/3dwarehouse/details?mid=2c6fd128fca34052adc5f5b98d513da1